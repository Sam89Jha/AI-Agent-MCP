import json
import os
from datetime import datetime
from typing import Dict, Any
import logging
from in_memory_cache import cache

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# In-memory connection tracking (in production, use DynamoDB)
connections_cache = {}

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda function to handle WebSocket connections and call events.
    """
    try:
        logger.info(f"WebSocket event: {json.dumps(event)}")
        
        # Extract connection details
        connection_id = event.get('requestContext', {}).get('connectionId')
        route_key = event.get('requestContext', {}).get('routeKey')
        
        if not connection_id:
            return {
                'statusCode': 400,
                'body': 'Missing connection ID'
            }
        
        # Handle different WebSocket events
        if route_key == '$connect':
            return handle_connect(event, connection_id)
        elif route_key == '$disconnect':
            return handle_disconnect(event, connection_id)
        elif route_key == 'message':
            return handle_message(event, connection_id)
        else:
            return {
                'statusCode': 400,
                'body': f'Unknown route key: {route_key}'
            }
            
    except Exception as e:
        logger.error(f"WebSocket handler error: {str(e)}")
        return {
            'statusCode': 500,
            'body': f'Internal server error: {str(e)}'
        }

def handle_connect(event: Dict[str, Any], connection_id: str) -> Dict[str, Any]:
    """
    Handle WebSocket connection.
    """
    try:
        # Extract booking code from query parameters
        query_params = event.get('queryStringParameters', {})
        booking_code = query_params.get('booking_code')
        
        if not booking_code:
            return {
                'statusCode': 400,
                'body': 'Missing booking_code parameter'
            }
        
        # Store connection in memory cache
        if booking_code not in connections_cache:
            connections_cache[booking_code] = []
        
        connections_cache[booking_code].append(connection_id)
        logger.info(f"Connection {connection_id} stored for booking {booking_code}")
        
        return {
            'statusCode': 200,
            'body': 'Connected'
        }
        
    except Exception as e:
        logger.error(f"Connect error: {str(e)}")
        return {
            'statusCode': 500,
            'body': f'Connection error: {str(e)}'
        }

def handle_disconnect(event: Dict[str, Any], connection_id: str) -> Dict[str, Any]:
    """
    Handle WebSocket disconnection.
    """
    try:
        # Remove connection from memory cache
        for booking_code, connections in connections_cache.items():
            if connection_id in connections:
                connections.remove(connection_id)
                logger.info(f"Connection {connection_id} removed from booking {booking_code}")
                break
        
        return {
            'statusCode': 200,
            'body': 'Disconnected'
        }
        
    except Exception as e:
        logger.error(f"Disconnect error: {str(e)}")
        return {
            'statusCode': 500,
            'body': f'Disconnect error: {str(e)}'
        }

def handle_message(event: Dict[str, Any], connection_id: str) -> Dict[str, Any]:
    """
    Handle WebSocket message (call events).
    """
    try:
        # Parse message body
        body = json.loads(event.get('body', '{}'))
        message_type = body.get('type')
        booking_code = body.get('booking_code')
        sender = body.get('from')
        
        if not all([message_type, booking_code, sender]):
            return {
                'statusCode': 400,
                'body': 'Missing required fields: type, booking_code, from'
            }
        
        # Handle different message types
        if message_type in ['call_initiate', 'call_accept', 'call_reject', 'call_end', 'call_ringing', 'call_connected']:
            return handle_call_event(body, booking_code, sender)
        else:
            return {
                'statusCode': 400,
                'body': f'Unknown message type: {message_type}'
            }
            
    except Exception as e:
        logger.error(f"Message handling error: {str(e)}")
        return {
            'statusCode': 500,
            'body': f'Message error: {str(e)}'
        }

def handle_call_event(event_data: Dict[str, Any], booking_code: str, sender: str) -> Dict[str, Any]:
    """
    Handle call-related events and broadcast to all connections.
    """
    try:
        message_type = event_data.get('type')
        if not message_type:
            return {
                'statusCode': 400,
                'body': 'Missing message type'
            }
        
        duration = event_data.get('duration', 0)
        timestamp = datetime.now().isoformat()
        
        # Create call log entry
        call_log = {
            'message': get_call_message(str(message_type), sender, duration),
            'status': get_call_status(str(message_type)),
            'duration': duration,
            'timestamp': timestamp,
            'from': sender
        }
        
        # Store call log in cache
        call_data = {
            'timestamp': timestamp,
            'call_type': message_type,
            'status': get_call_status(str(message_type)),
            'duration': duration
        }
        
        cache.add_call(booking_code, call_data)
        
        # Prepare WebSocket broadcast message
        broadcast_message = {
            'type': message_type,
            'from': sender,
            'booking_code': booking_code,
            'timestamp': timestamp,
            'call_log': call_log
        }
        
        # Broadcast to all connections for this booking
        connections = get_connections_for_booking(booking_code)
        
        for conn_id in connections:
            try:
                # In production, this would use API Gateway Management API
                logger.info(f"Would send to connection {conn_id}: {broadcast_message}")
            except Exception as e:
                logger.error(f"Failed to send to connection {conn_id}: {str(e)}")
                # Remove stale connection
                remove_connection(conn_id)
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'success': True,
                'message': 'Call event processed',
                'broadcast_count': len(connections)
            })
        }
        
    except Exception as e:
        logger.error(f"Call event error: {str(e)}")
        return {
            'statusCode': 500,
            'body': f'Call event error: {str(e)}'
        }

def get_call_message(message_type: str, sender: str, duration: int = 0) -> str:
    """Generate call message based on type."""
    messages = {
        'call_initiate': f'Call initiated by {sender}',
        'call_accept': f'Call accepted by {sender}',
        'call_reject': f'Call rejected by {sender}',
        'call_end': f'Call ended by {sender} (Duration: {duration}s)',
        'call_ringing': f'Call ringing for {sender}',
        'call_connected': f'Call connected for {sender}'
    }
    return messages.get(message_type, f'Call event: {message_type}')

def get_call_status(message_type: str) -> str:
    """Get call status based on message type."""
    status_map = {
        'call_initiate': 'initiated',
        'call_accept': 'accepted',
        'call_reject': 'rejected',
        'call_end': 'ended',
        'call_ringing': 'ringing',
        'call_connected': 'connected'
    }
    return status_map.get(message_type, 'unknown')

def get_connections_for_booking(booking_code: str) -> list:
    """
    Get all WebSocket connections for a booking code.
    """
    return connections_cache.get(booking_code, [])

def remove_connection(connection_id: str):
    """
    Remove a stale WebSocket connection.
    """
    for booking_code, connections in connections_cache.items():
        if connection_id in connections:
            connections.remove(connection_id)
            logger.info(f"Removed stale connection {connection_id} from booking {booking_code}")
            break 